package Package;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import org.json.simple.parser.ParseException;


public class Menu {
    ArrayList<Zapatilla> zap;
    Archivos ar=new Archivos();

    /**
     * Menu principal de la aplicación.
     * @throws org.json.simple.parser.ParseException
     */
    public void inicio() throws ParseException {
        String ruta="";
        boolean estado = true;
        while (estado) {
            System.out.println("¿Que desea hacer?");
            System.out.println("1. Sacar informacion de Archivo JSON");
            System.out.println("2. Meter la informacion en un archivo JSON");
            System.out.println("3. Ver la información");
            System.out.println("4. Agregar informacion");
            System.out.println("5. Salir");
            int opcion = validarNumero();
            switch (opcion) {
                case 1:
                        System.out.println("Ingrese la ruta");
                        System.out.println("Ejemplo: C:\\Users\\Diego Lagos\\Downloads\\zapatillas.json");
                        ruta=validarPalabra();
                        ar.JSONArrayAobjetos(ar.leerArchivo(ruta));
                        zap=ar.getArregloS();                       
                    break;
                case 2: System.out.println("Ingrese la ruta");
                    System.out.println("Ejemplo: C:\\Users\\Diego Lagos\\Desktop\\Archivo.json");
                        ruta=validarPalabra();
                        ar.crearArchivoJ(ruta, zap);
                    break;
                case 3: System.out.println("Lista de zapatillas");
                        for(int i=0;i<zap.size();i++){
                            System.out.println("Marca: "+zap.get(i).getMarca());
                            System.out.println("Modelo: "+zap.get(i).getModelo());
                            System.out.println("Color: "+zap.get(i).getColor());
                            System.out.println("");
                        }
                    break;
                case 4: System.out.println("Ingrese la marca de la zapatilla");
                        String marca=validarPalabra();
                        System.out.println("Ingrese el modelo");
                        String modelo=validarPalabra();
                        System.out.println("Ingrese el color");
                        String color=validarPalabra();
                        Zapatilla n=new Zapatilla(marca,modelo,color);
                        zap.add(n);
                    break;
                case 5:
                    estado = false;
                    break;

            }
        }
    }
    
    public static String validarPalabra() {
        String num = " ";
        boolean estado = true;

        while (estado) {

            try {
                Scanner leer = new Scanner(System.in);

                num = leer.nextLine();
                estado = false;

            } catch (InputMismatchException e) {
                System.out.println("El caracter ingresado no es una palabra, intentelo nuevamente.");
                estado = true;
            }

        }
        return num;
    }
    public static int validarNumero() {
    int num = 0;
    boolean estado = true;

    while (estado) {

        try {
            System.out.println("Ingrese un numero");
            Scanner leer = new Scanner(System.in);

            num = leer.nextInt();
            estado = false;

        } catch (InputMismatchException e) {
            System.out.println("El caracter ingresado no es numerico o se encuentra fuera del rango establecido, intentelo nuevamente.");
            estado = true;
        }

    }
    return num;
}
}
